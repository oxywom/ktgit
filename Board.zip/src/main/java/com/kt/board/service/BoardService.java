package com.kt.board.service;

import java.util.List;

import com.kt.board.dto.Board;

public interface BoardService {
	List<Board> getBoardList() throws Exception;
}
