package com.kt.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.kt.board.dao.BoardDAO;
import com.kt.board.dto.Board;

public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDAO boardDAO;
	
	@Override
	public List<Board> getBoardList() throws Exception {
		return boardDAO.selectBoardList();
	}

}
