package com.kr.aop.ex2;

public interface MessageBean {
	void sayHello();
}
