package com.kr.aop.ex1;

public interface MessageBean {
	void sayHello();
}
