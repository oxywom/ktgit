package com.kt.di.ex2;

public interface MessageBean {
	public void sayHello();
}
