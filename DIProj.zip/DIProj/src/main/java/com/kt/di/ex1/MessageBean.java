package com.kt.di.ex1;

public interface MessageBean {
	public void sayHello(String name);
}
