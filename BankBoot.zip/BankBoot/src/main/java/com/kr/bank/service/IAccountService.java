package com.kr.bank.service;

import java.util.List;

import com.kr.bank.dto.Account;

public interface IAccountService {
	List<Account> accountList() throws Exception;
	void makeAccount(Account acc) throws Exception;
	Boolean doubleId(String id) throws Exception;
	Account deposit(String id, Integer money) throws Exception;
	Account withdraw(String id, Integer money) throws Exception;
	Account accountInfo(String id) throws Exception;
}
