package com.kr.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kr.bank.dao.AccountDAO;
import com.kr.bank.dto.Account;

@Service
public class AccountService implements IAccountService {

	@Autowired
	AccountDAO accountDAO;
	
	@Override
	public List<Account> accountList() throws Exception {
		// TODO Auto-generated method stub
		return accountDAO.selectAllAccount();
	}
	
	@Override
	public void makeAccount(Account acc) throws Exception {
		accountDAO.insertAccount(acc);
	}

	@Override
	public Boolean doubleId(String id) throws Exception {
		Account acc = accountDAO.selectAccount(id);
		if(acc==null) return false;
		return true;
	}

	@Override
	public Account deposit(String id, Integer money) throws Exception {
		Account acc = accountDAO.selectAccount(id);
		if(acc==null) throw new Exception("계좌번호 오류");
		acc.deposit(money);
		accountDAO.updateBalance(acc);
		return acc;
	}

	@Override
	public Account withdraw(String id, Integer money) throws Exception {
		Account acc = accountDAO.selectAccount(id);
		if(acc==null) throw new Exception("계좌번호 오류");
		acc.withdraw(money);
		accountDAO.updateBalance(acc);
		return acc;
	}

	@Override
	public Account accountInfo(String id) throws Exception {
		return accountDAO.selectAccount(id);
	}
}
