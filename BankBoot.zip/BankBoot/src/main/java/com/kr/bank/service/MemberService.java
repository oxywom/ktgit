package com.kr.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kr.bank.dao.MemberDAO;
import com.kr.bank.dto.Member;

@Service
public class MemberService implements IMemberService {

	@Autowired
	MemberDAO memberDAO;
	
	@Override
	public void join(Member member) throws Exception {
		memberDAO.insertMember(member);
	}

	@Override
	public void login(String id, String password) throws Exception {
		Member member = memberDAO.selectMember(id);
		if(member==null) throw new Exception("아이디 오류");
		if(!member.getPassword().equals(password)) {
			throw new Exception("비밀번호 오류");
		}
	}

}
