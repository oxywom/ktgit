package com.kr.bank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kr.bank.dto.Member;
import com.kr.bank.service.IMemberService;

@Controller
public class MemberController {
	
	@Autowired
	IMemberService memberService;
	
	@Autowired
	HttpSession session;
	
	@GetMapping("/join")
	public String join() {
		return "join";
	}
	
	@PostMapping("/join")
	public String join(@ModelAttribute Member member, Model model) {
		try {
			memberService.join(member);
			return "login";
		} catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("err", "회원가입 실패");
			return "error";
		}
	}	

	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login")
	public String login(@RequestParam("id") String id, 
			@RequestParam("password") String password,
			Model model) {
		try {
			memberService.login(id,password);
			session.setAttribute("id", id);
			return "makeAccount";
		} catch(Exception e) { 
			e.printStackTrace();
			model.addAttribute("err", e.getMessage());
			return "error";			
		}
	}	
	
	@GetMapping("/logout")
	public String logout() {
		session.removeAttribute("id");
		return "login";
	}
}
